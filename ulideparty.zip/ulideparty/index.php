<!DOCTYPE html>
<html style="font-size: 16px;" lang="en">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Gluten-Free Bakery, Who We Are, Special Menu, Special Menu, What We Do, Location, INTUITIVE">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>Pagina inicial</title>
    <link rel="stylesheet" href="stylesheets/nicepage.css" media="screen">
<link rel="stylesheet" href="stylesheets/home-page.css" media="screen">
    <script class="u-script" type="text/javascript" src="javascripts/jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="javascripts/nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 4.7.1, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    
    
    
    
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": ""
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="Pagina inicial">
    <meta property="og:type" content="website">
  </head>
  <body data-home-page="Pagina-inicial.html" data-home-page-title="Pagina inicial" class="u-body u-xl-mode"><header class="u-clearfix u-grey-80 u-header u-sticky u-sticky-c6e0 u-header" id="sec-fbb9"><div class="u-clearfix u-sheet u-valign-middle-lg u-sheet-1">
        <img class="u-image u-image-default u-image-1" src="images/logos/logo_m.png" alt="">
        <nav class="u-menu u-menu-dropdown u-offcanvas u-menu-1">
          <div class="menu-collapse" style="font-size: 1rem; letter-spacing: 0;">
            <a class="u-button-style u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-text-active-color u-custom-text-color u-custom-text-hover-color u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="#" style="padding: 4px 0; font-size: calc(1em + 8px);">
              <svg class="u-svg-link" viewBox="0 0 24 24"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#menu-hamburger"></use></svg>
              <svg class="u-svg-content" version="1.1" id="menu-hamburger" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</g></svg>
            </a>
          </div>
          <div class="u-custom-menu u-nav-container">
            <ul class="u-nav u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-white u-text-hover-palette-1-base u-text-white" href="index.php" style="padding: 10px 20px;">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-white u-text-hover-palette-1-base u-text-white" href="dashboard/index.php" target="_blank" style="padding: 10px 20px;">DashBoard</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-white u-text-hover-palette-1-base u-text-white" href="index.php" style="padding: 10px 20px;">Pagina inicial</a>
</li></ul>
          </div>
          <div class="u-custom-menu u-nav-container-collapse">
            <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
              <div class="u-inner-container-layout u-sidenav-overflow">
                <div class="u-menu-close"></div>
                <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="index.php">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="dashboard/index.php" target="_blank">DashBoard</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="index.php">Pagina inicial</a>
</li></ul>
              </div>
            </div>
            <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
          </div>
        </nav>
        <h6 class="u-text u-text-default u-text-1">
          <a class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-hover-palette-1-base u-text-white u-btn-1" href="dashboard/login.php" data-page-id="818010508">Login</a>
        </h6>
        <h6 class="u-text u-text-default u-text-2">
          <a class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-hover-palette-1-base u-text-white u-btn-2" href="dashboard/register.php" data-page-id="818010508">Registar</a>
        </h6>
      </div></header>
    <section class="u-clearfix u-image u-typography-custom-page-typography-8--Introduction u-section-1" id="carousel_288f" data-image-width="2048" data-image-height="1367">
      <div class="u-clearfix u-sheet u-sheet-1">
        <img class="u-image u-image-default u-image-1" src="images/logos/logo_g.png" alt="">
        <form action="#" method="get" class="u-border-1 u-border-grey-30 u-search u-search-left u-white u-search-1">
          <button class="u-search-button" type="submit">
            <span class="u-search-icon u-spacing-10">
              <svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 56.966 56.966"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-707f"></use></svg>
              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="svg-707f" x="0px" y="0px" viewBox="0 0 56.966 56.966" style="enable-background:new 0 0 56.966 56.966;" xml:space="preserve" class="u-svg-content"><path d="M55.146,51.887L41.588,37.786c3.486-4.144,5.396-9.358,5.396-14.786c0-12.682-10.318-23-23-23s-23,10.318-23,23  s10.318,23,23,23c4.761,0,9.298-1.436,13.177-4.162l13.661,14.208c0.571,0.593,1.339,0.92,2.162,0.92  c0.779,0,1.518-0.297,2.079-0.837C56.255,54.982,56.293,53.08,55.146,51.887z M23.984,6c9.374,0,17,7.626,17,17s-7.626,17-17,17  s-17-7.626-17-17S14.61,6,23.984,6z"></path></svg>
            </span>
          </button>
          <input class="u-search-input" type="search" name="search" value="" placeholder="Search">
        </form>
        <h3 class="u-text u-text-default u-text-white u-text-1">A diversão começa aqui !!!</h3>
      </div>
    </section>
    <section class="u-clearfix u-gradient u-section-2" id="carousel_1f33">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-disable-padding u-expanded-width u-gutter-0 u-layout-wrap u-layout-wrap-1">
          <div class="u-gutter-0 u-layout">
            <div class="u-layout-row">
              <div class="u-align-left u-container-style u-hover-feature u-image u-image-default u-layout-cell u-left-cell u-opacity u-opacity-90 u-size-20 u-size-20-md u-image-1" data-image-width="3264" data-image-height="4928" data-href="listas.php" data-page-id="152516469">
                <div class="u-container-layout u-container-layout-1">
                  <h6 class="u-text u-text-default u-text-white u-text-1">Restaurantes</h6>
                </div>
              </div>
              <div class="u-align-left u-container-style u-hover-feature u-image u-layout-cell u-opacity u-opacity-90 u-size-20 u-size-20-md u-image-2" data-image-width="1067" data-image-height="1600" data-href="listas.php">
                <div class="u-container-layout u-container-layout-2">
                  <h6 class="u-text u-text-default u-text-white u-text-2">Bares</h6>
                </div>
              </div>
              <div class="u-align-left u-container-style u-hover-feature u-image u-layout-cell u-opacity u-opacity-90 u-right-cell u-size-20 u-size-20-md u-image-3" data-image-width="1600" data-image-height="1067" data-href="listas.php">
                <div class="u-container-layout u-container-layout-3">
                  <h6 class="u-text u-text-default u-text-white u-text-3">Discotecas</h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      
      
    </section>
    <section class="u-clearfix u-gradient u-section-3" id="carousel_f187">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-expanded-width-xs u-layout-wrap u-layout-wrap-1">
          <div class="u-gutter-0 u-layout">
            <div class="u-layout-row">
              <div class="u-align-center-lg u-align-center-sm u-align-center-xl u-align-center-xs u-container-style u-layout-cell u-left-cell u-opacity u-opacity-90 u-size-19 u-white u-layout-cell-1">
                <div class="u-container-layout u-valign-middle u-container-layout-1">
                  <h2 class="u-align-center-md u-text u-text-1">Who We Are</h2>
                </div>
              </div>
              <div class="u-container-style u-layout-cell u-opacity u-opacity-90 u-right-cell u-size-41 u-white u-layout-cell-2">
                <div class="u-container-layout u-valign-middle u-container-layout-2">
                  <p class="u-text u-text-font u-text-2">We are a privately owned artisanal bakery and cafe, located in New York. We provide fresh, handmade, from scratch, pastries, bread, coffee &amp; lunch containing no preservatives or additives.&nbsp;<br>
                    <br>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-gradient u-section-4" id="carousel_0357">
      <div class="u-clearfix u-sheet u-sheet-1">
        <img src="images/hannah-busing-Zyx1bK9mqmA-unsplash.jpg" class="u-align-left u-expanded-width-xs u-image u-image-1" data-image-width="1600" data-image-height="1067">
        <div class="u-align-center-md u-align-center-sm u-align-center-xs u-align-left-lg u-align-left-xl u-border-10 u-border-palette-1-light-2 u-container-style u-group u-white u-group-1">
          <div class="u-container-layout u-padding-12 u-valign-middle u-container-layout-1">
            <h2 class="u-heading-font u-text u-text-palette-1-base u-text-1">Dashboard</h2>
            <div class="u-border-1 u-border-palette-1-base u-line u-line-horizontal u-line-1"></div>
            <p class="u-text u-text-font u-text-2">Jonte-se a nos e ajude a nossa comedidade a dicar mais forte.&nbsp;</p>
            <a href="https://nicepage.one" class="u-border-1 u-border-palette-1-base u-btn u-button-style u-text-body-color u-btn-1">more</a>
          </div>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-image u-typography-custom-page-typography-13--Map u-section-5" id="carousel_ad5c" data-image-width="276" data-image-height="183">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-expanded-width-sm u-expanded-width-xs u-layout-wrap u-layout-wrap-1">
          <div class="u-layout">
            <div class="u-layout-col">
              <div class="u-align-center u-container-style u-layout-cell u-left-cell u-right-cell u-similar-fill u-size-30 u-white u-layout-cell-1">
                <div class="u-container-layout u-valign-middle u-container-layout-1">
                  <h2 class="u-heading-font u-text u-text-1">Location</h2>
                  <p class="u-text u-text-font u-text-2">Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit nullam nunc justo sagittis suscipit ultrices.</p>
                </div>
              </div>
              <div class="u-container-style u-layout-cell u-left-cell u-right-cell u-size-30 u-layout-cell-2">
                <div class="u-container-layout">
                  <div class="u-expanded u-grey-light-2 u-map">
                    <div class="embed-responsive">
                      <iframe class="embed-responsive-item" src="//maps.google.com/maps?output=embed&amp;q=iade%2C%20lisboa&amp;z=16&amp;t=m&amp;hl=pt" data-map="JTdCJTIycG9zaXRpb25UeXBlJTIyJTNBJTIybWFwLWFkZHJlc3MlMjIlMkMlMjJhZGRyZXNzJTIyJTNBJTIyaWFkZSUyQyUyMGxpc2JvYSUyMiUyQyUyMnpvb20lMjIlM0ExNiUyQyUyMnR5cGVJZCUyMiUzQSUyMnJvYWQlMjIlMkMlMjJsYW5nJTIyJTNBJTIycHQlMjIlN0Q="></iframe>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-fa49"><div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1">Copyright - Ulide Party 2022</p>
      </div></footer>
    <section class="u-backlink u-clearfix u-grey-80">
      <a class="u-link" href="https://nicepage.com/website-templates" target="_blank">
        <span>Website Templates</span>
      </a>
      <p class="u-text">
        <span>created with</span>
      </p>
      <a class="u-link" href="" target="_blank">
        <span>Website Builder Software</span>
      </a>. 
    </section>
  </body>
</html>