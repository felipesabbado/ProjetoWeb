<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Sample Headline">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>Listas</title>
    <link rel="stylesheet" href="stylesheets/nicepage.css" media="screen">
<link rel="stylesheet" href="stylesheets/listas.css" media="screen">
    <script class="u-script" type="text/javascript" src="javascripts/jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="javascripts/nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 4.7.1, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": ""
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="Listas">
    <meta property="og:type" content="website">
  </head>
  <body class="u-body u-xl-mode"><header class="u-clearfix u-grey-80 u-header u-sticky u-sticky-c6e0 u-header" id="sec-fbb9"><div class="u-clearfix u-sheet u-valign-middle-lg u-sheet-1">
        <img class="u-image u-image-default u-image-1" src="images/logos/logo_m.png" alt="">
        <nav class="u-menu u-menu-dropdown u-offcanvas u-menu-1">
          <div class="menu-collapse" style="font-size: 1rem; letter-spacing: 0px;">
            <a class="u-button-style u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-text-active-color u-custom-text-color u-custom-text-hover-color u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="#" style="padding: 4px 0px; font-size: calc(1em + 8px);">
              <svg class="u-svg-link" viewBox="0 0 24 24"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#menu-hamburger"></use></svg>
              <svg class="u-svg-content" version="1.1" id="menu-hamburger" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</g></svg>
            </a>
          </div>
          <div class="u-custom-menu u-nav-container">
            <ul class="u-nav u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-white u-text-hover-palette-1-base u-text-white" href="index.php" style="padding: 10px 20px;">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-white u-text-hover-palette-1-base u-text-white" style="padding: 10px 20px;">DashBoard</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link u-text-active-white u-text-hover-palette-1-base u-text-white" href="index.php" style="padding: 10px 20px;">Pagina inicial</a>
</li></ul>
          </div>
          <div class="u-custom-menu u-nav-container-collapse">
            <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
              <div class="u-inner-container-layout u-sidenav-overflow">
                <div class="u-menu-close"></div>
                <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="index.php">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link">DashBoard</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="index.php">Pagina inicial</a>
</li></ul>
              </div>
            </div>
            <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
          </div>
        </nav>
        <h6 class="u-text u-text-default u-text-1">
          <a class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-hover-palette-1-base u-text-white u-btn-1" href="Login.html" data-page-id="818010508">Login</a>
        </h6>
        <h6 class="u-text u-text-default u-text-2">
          <a class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-hover-palette-1-base u-text-white u-btn-2" href="Login.html" data-page-id="818010508">Registar</a>
        </h6>
      </div></header>
    <section class="u-align-center u-clearfix u-image u-shading u-section-1" src="" data-image-width="3883" data-image-height="2912" id="sec-ce9e">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h1 class="u-text u-text-default u-title u-text-1">Restaurantes</h1>
        <p class="u-large-text u-text u-text-variant u-text-2">Descobre os melhores restaurantes de Lisboa.&nbsp;</p>
      </div>
    </section>
    <section class="u-clearfix u-gradient u-section-2" id="sec-d998">
      <div class="u-clearfix u-sheet u-sheet-1">
        <a href="https://nicepage.com/html-website-builder" class="u-btn u-button-style u-btn-1"><span class="u-file-icon u-icon"><img src="images/57164.png" alt=""></span>&nbsp;Filtros
        </a>
        <div class="u-expanded-width u-list u-list-1">
          <div class="u-repeater u-repeater-1">
            <div class="u-container-style u-hover-feature u-list-item u-repeater-item u-video-cover u-white u-list-item-1" data-href="info.php" data-page-id="170745537">
              <div class="u-container-layout u-similar-container u-valign-bottom-lg u-container-layout-1">
                <h3 class="u-text u-text-default-xl u-text-1"> Amélia Lisboa</h3>
                <div class="u-border-4 u-border-palette-3-base u-expanded-width u-line u-line-horizontal u-line-1"></div>
                <img alt="" class="u-expanded-width-lg u-expanded-width-md u-expanded-width-sm u-expanded-width-xs u-image u-image-default u-image-1" data-image-width="675" data-image-height="450" src="images/rest01.webp">
                <h6 class="u-text u-text-2"> 4.4&nbsp;<span class="u-file-icon u-icon"><img src="images/1828884.png" alt=""></span>
                </h6>
                <p class="u-text u-text-3">Sobremesas, sumos, ...</p>
                <h6 class="u-text u-text-4">Campo de ourique, lisboa</h6>
                <h6 class="u-custom-item u-text u-text-custom-color-2 u-text-5">Abre em 20 minutos</h6>
              </div>
            </div>
            <div class="u-container-style u-hover-feature u-list-item u-repeater-item u-video-cover u-white u-list-item-2">
              <div class="u-container-layout u-similar-container u-valign-bottom-lg u-container-layout-2">
                <h3 class="u-text u-text-default-xl u-text-6">Memoria</h3>
                <div class="u-border-4 u-border-palette-3-base u-expanded-width u-line u-line-horizontal u-line-2"></div>
                <img alt="" class="u-expanded-width-lg u-expanded-width-md u-expanded-width-sm u-expanded-width-xs u-image u-image-default u-image-2" data-image-width="675" data-image-height="900" src="images/rest02.webp">
                <h6 class="u-text u-text-7"> 4.4&nbsp;&nbsp;<span class="u-file-icon u-icon"><img src="images/18288841.png" alt=""></span> &nbsp;
                </h6>
                <p class="u-text u-text-8"> Sobremesas, sumos, ...</p>
                <h6 class="u-text u-text-9"> Campo de ourique, lisboa</h6>
                <h6 class="u-custom-item u-text u-text-10">Tirar </h6>
              </div>
            </div>
            <div class="u-container-style u-hover-feature u-list-item u-repeater-item u-video-cover u-white u-list-item-3">
              <div class="u-container-layout u-similar-container u-valign-bottom-lg u-container-layout-3">
                <h3 class="u-text u-text-default-xl u-text-11">A minha cozinha</h3>
                <div class="u-border-4 u-border-palette-3-base u-expanded-width u-line u-line-horizontal u-line-3"></div>
                <img alt="" class="u-expanded-width-lg u-expanded-width-md u-expanded-width-sm u-expanded-width-xs u-image u-image-default u-image-3" data-image-width="675" data-image-height="898" src="images/rest03.webp">
                <h6 class="u-text u-text-12">4.4&nbsp;<span class="u-file-icon u-icon"><img src="images/18288842.png" alt=""></span>
                </h6>
                <p class="u-text u-text-13"> Sobremesas, sumos, ...</p>
                <h6 class="u-text u-text-14"> Campo de ourique, lisboa</h6>
                <h6 class="u-custom-item u-text u-text-palette-2-base u-text-15">Fecha em 30 minutos</h6>
              </div>
            </div>
            <div class="u-container-style u-hover-feature u-list-item u-repeater-item u-video-cover u-white u-list-item-4">
              <div class="u-container-layout u-similar-container u-valign-bottom-lg u-container-layout-4">
                <h3 class="u-text u-text-default-xl u-text-16">Pigmeu</h3>
                <div class="u-border-4 u-border-palette-3-base u-expanded-width u-line u-line-horizontal u-line-4"></div>
                <img alt="" class="u-expanded-width-lg u-expanded-width-md u-expanded-width-sm u-expanded-width-xs u-image u-image-default u-image-4" data-image-width="675" data-image-height="506" src="images/rest04.webp">
                <h6 class="u-text u-text-17">4.4&nbsp;<span class="u-file-icon u-icon"><img src="images/18288843.png" alt=""></span>
                </h6>
                <p class="u-text u-text-18">kjxcn, idjfsjd, ..</p>
                <h6 class="u-text u-text-19"> Campo de ourique, lisboa</h6>
                <h6 class="u-custom-item u-text u-text-custom-color-2 u-text-20">Tempo</h6>
              </div>
            </div>
            <div class="u-container-style u-hover-feature u-list-item u-repeater-item u-video-cover u-white u-list-item-5">
              <div class="u-container-layout u-similar-container u-valign-bottom-lg u-container-layout-5">
                <h3 class="u-text u-text-default-xl u-text-21">Fiammetta</h3>
                <div class="u-border-4 u-border-palette-3-base u-expanded-width u-line u-line-horizontal u-line-5"></div>
                <img alt="" class="u-expanded-width-lg u-expanded-width-md u-expanded-width-sm u-expanded-width-xs u-image u-image-default u-image-5" data-image-width="675" data-image-height="506" src="images/rest05.webp">
                <h6 class="u-text u-text-22">4.4&nbsp;<span class="u-file-icon u-icon"><img src="images/18288844.png" alt=""></span>
                </h6>
                <p class="u-text u-text-23">hfkjahfjasfkjh</p>
                <h6 class="u-text u-text-24"> Campo de ourique, lisboa</h6>
                <h6 class="u-custom-item u-text u-text-custom-color-2 u-text-25">Tempo</h6>
              </div>
            </div>
            <div class="u-container-style u-hover-feature u-list-item u-repeater-item u-video-cover u-white u-list-item-6">
              <div class="u-container-layout u-similar-container u-valign-bottom-lg u-container-layout-6">
                <h3 class="u-text u-text-default-xl u-text-26">Atalho do mercado</h3>
                <div class="u-border-4 u-border-palette-3-base u-expanded-width u-line u-line-horizontal u-line-6"></div>
                <img alt="" class="u-expanded-width-lg u-expanded-width-md u-expanded-width-sm u-expanded-width-xs u-image u-image-default u-image-6" data-image-width="675" data-image-height="261" src="images/rest06.webp">
                <h6 class="u-text u-text-27"><span class="u-icon u-icon-7"></span>&nbsp;4.4<span class="u-file-icon u-icon"><img src="images/18288847.png" alt=""></span>&nbsp; 
                </h6>
                <p class="u-text u-text-28">jjdshfkjhsdjhf</p>
                <h6 class="u-text u-text-29"> Campo de ourique, lisboa</h6>
                <h6 class="u-custom-item u-text u-text-custom-color-2 u-text-30">Tempo</h6>
              </div>
            </div>
          </div>
        </div>
        <a href="https://nicepage.me" class="u-btn u-btn-round u-button-style u-hover-palette-1-light-1 u-palette-1-base u-radius-50 u-btn-2">Mostrar mais</a>
      </div>
      
      
      
      
      
      
    </section>
    
    
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-fa49"><div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1">Copyright - Ulide Party 2022</p>
      </div></footer>
    <section class="u-backlink u-clearfix u-grey-80">
      <a class="u-link" href="https://nicepage.com/website-templates" target="_blank">
        <span>Website Templates</span>
      </a>
      <p class="u-text">
        <span>created with</span>
      </p>
      <a class="u-link" href="" target="_blank">
        <span>Website Builder Software</span>
      </a>. 
    </section>
  </body>
</html>